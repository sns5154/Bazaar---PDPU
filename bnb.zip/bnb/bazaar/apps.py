from django.apps import AppConfig


class BazaarConfig(AppConfig):
    name = 'bazaar'
